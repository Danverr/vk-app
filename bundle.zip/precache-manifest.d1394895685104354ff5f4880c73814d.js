self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "34d00430a2b058973aa6dd43b7b850d0",
    "url": "./index.html"
  },
  {
    "revision": "23a410a78c41bb0d34eb",
    "url": "./static/css/2.85b3d357.chunk.css"
  },
  {
    "revision": "f834e0a0785e8a21fcf6",
    "url": "./static/css/main.649ac1ab.chunk.css"
  },
  {
    "revision": "23a410a78c41bb0d34eb",
    "url": "./static/js/2.c0bafdc6.chunk.js"
  },
  {
    "revision": "f05b575269763176f772a28425199a48",
    "url": "./static/js/2.c0bafdc6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "067e96da9585d261fab6",
    "url": "./static/js/3.ea918592.chunk.js"
  },
  {
    "revision": "82a84ee2e9c08a120ef2c0e392073364",
    "url": "./static/js/3.ea918592.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c552411bbb0eb68ec679",
    "url": "./static/js/4.31e88372.chunk.js"
  },
  {
    "revision": "f834e0a0785e8a21fcf6",
    "url": "./static/js/main.938b3404.chunk.js"
  },
  {
    "revision": "9520f7514a22f9f91f4c",
    "url": "./static/js/runtime-main.8894b19b.js"
  },
  {
    "revision": "1d6fed1e80bdfd68b43a255b7173cfbf",
    "url": "./static/media/anxiety1.1d6fed1e.png"
  },
  {
    "revision": "83610c4dc7b241fcb6e84285c3e62ca0",
    "url": "./static/media/anxiety2.83610c4d.png"
  },
  {
    "revision": "eed3bce18630c9650ac1736a2a640513",
    "url": "./static/media/anxiety3.eed3bce1.png"
  },
  {
    "revision": "aead2bab86aca939210c353422fa3b90",
    "url": "./static/media/anxiety4.aead2bab.png"
  },
  {
    "revision": "675a7b11b80ff92acef7a3e4e5f981f8",
    "url": "./static/media/anxiety5.675a7b11.png"
  },
  {
    "revision": "2399fba075e7e9716d8e0b0f2e43adc7",
    "url": "./static/media/bannerCover.2399fba0.png"
  },
  {
    "revision": "00b33c4640b372fa32e94310dfaf6684",
    "url": "./static/media/intro0.00b33c46.jpg"
  },
  {
    "revision": "9a333ba598c1d604dee4a6d773276fcd",
    "url": "./static/media/intro1.9a333ba5.jpg"
  },
  {
    "revision": "7b1ffdcd9153a4f466bc723d841bf0a6",
    "url": "./static/media/intro2.7b1ffdcd.jpg"
  },
  {
    "revision": "605334eea425cf2631e43ebbc4a040e7",
    "url": "./static/media/logo.605334ee.png"
  },
  {
    "revision": "323d3092987d271476aff83525cadd80",
    "url": "./static/media/logoDark.323d3092.png"
  },
  {
    "revision": "cdd30ddb217323b08a638dfa919d455a",
    "url": "./static/media/mood1.cdd30ddb.png"
  },
  {
    "revision": "fcf0e55c4f93f3a4f21123637dc672af",
    "url": "./static/media/mood2.fcf0e55c.png"
  },
  {
    "revision": "00683d471778d55e1eec35ef325b211d",
    "url": "./static/media/mood3.00683d47.png"
  },
  {
    "revision": "e9a7f3fc5b6e167f3c2ce39e3971c896",
    "url": "./static/media/mood4.e9a7f3fc.png"
  },
  {
    "revision": "9fa790a06e6653857105152bf7988c6e",
    "url": "./static/media/mood5.9fa790a0.png"
  },
  {
    "revision": "1d6fed1e80bdfd68b43a255b7173cfbf",
    "url": "./static/media/stress1.1d6fed1e.png"
  },
  {
    "revision": "d10f2673e6338ed1b4618f3a9ee6912a",
    "url": "./static/media/stress2.d10f2673.png"
  },
  {
    "revision": "3cb05029cd5559ae803e1c6a5c04779b",
    "url": "./static/media/stress3.3cb05029.png"
  },
  {
    "revision": "6bc32b97f46941a422dc1faf06503692",
    "url": "./static/media/stress4.6bc32b97.png"
  },
  {
    "revision": "45425d6d67319197590ee323f8ebd810",
    "url": "./static/media/stress5.45425d6d.png"
  },
  {
    "revision": "7b666cff040aca533e4190699157778d",
    "url": "./static/media/thinkingFace.7b666cff.png"
  }
]);