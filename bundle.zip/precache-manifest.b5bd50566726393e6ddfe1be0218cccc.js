self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0a5c7b2cf9a9fe79bc2415b5cb2ad54a",
    "url": "./index.html"
  },
  {
    "revision": "bc2a1ca96fc9748e56b2",
    "url": "./static/css/2.85b3d357.chunk.css"
  },
  {
    "revision": "66b0b23eff54141e7f43",
    "url": "./static/css/main.4c1e2d16.chunk.css"
  },
  {
    "revision": "bc2a1ca96fc9748e56b2",
    "url": "./static/js/2.d71af99f.chunk.js"
  },
  {
    "revision": "f05b575269763176f772a28425199a48",
    "url": "./static/js/2.d71af99f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7b3aa9fa9cc89826af71",
    "url": "./static/js/3.2011c813.chunk.js"
  },
  {
    "revision": "82a84ee2e9c08a120ef2c0e392073364",
    "url": "./static/js/3.2011c813.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e2c53167fe3860989078",
    "url": "./static/js/4.702e4abd.chunk.js"
  },
  {
    "revision": "66b0b23eff54141e7f43",
    "url": "./static/js/main.21cafbc2.chunk.js"
  },
  {
    "revision": "ad2ef82d099d1b49c47e",
    "url": "./static/js/runtime-main.5ccfd4eb.js"
  },
  {
    "revision": "1d6fed1e80bdfd68b43a255b7173cfbf",
    "url": "./static/media/anxiety1.1d6fed1e.png"
  },
  {
    "revision": "83610c4dc7b241fcb6e84285c3e62ca0",
    "url": "./static/media/anxiety2.83610c4d.png"
  },
  {
    "revision": "eed3bce18630c9650ac1736a2a640513",
    "url": "./static/media/anxiety3.eed3bce1.png"
  },
  {
    "revision": "aead2bab86aca939210c353422fa3b90",
    "url": "./static/media/anxiety4.aead2bab.png"
  },
  {
    "revision": "675a7b11b80ff92acef7a3e4e5f981f8",
    "url": "./static/media/anxiety5.675a7b11.png"
  },
  {
    "revision": "00b33c4640b372fa32e94310dfaf6684",
    "url": "./static/media/intro0.00b33c46.jpg"
  },
  {
    "revision": "9a333ba598c1d604dee4a6d773276fcd",
    "url": "./static/media/intro1.9a333ba5.jpg"
  },
  {
    "revision": "7b1ffdcd9153a4f466bc723d841bf0a6",
    "url": "./static/media/intro2.7b1ffdcd.jpg"
  },
  {
    "revision": "605334eea425cf2631e43ebbc4a040e7",
    "url": "./static/media/logo.605334ee.png"
  },
  {
    "revision": "cdd30ddb217323b08a638dfa919d455a",
    "url": "./static/media/mood1.cdd30ddb.png"
  },
  {
    "revision": "fcf0e55c4f93f3a4f21123637dc672af",
    "url": "./static/media/mood2.fcf0e55c.png"
  },
  {
    "revision": "00683d471778d55e1eec35ef325b211d",
    "url": "./static/media/mood3.00683d47.png"
  },
  {
    "revision": "e9a7f3fc5b6e167f3c2ce39e3971c896",
    "url": "./static/media/mood4.e9a7f3fc.png"
  },
  {
    "revision": "9fa790a06e6653857105152bf7988c6e",
    "url": "./static/media/mood5.9fa790a0.png"
  },
  {
    "revision": "1d6fed1e80bdfd68b43a255b7173cfbf",
    "url": "./static/media/stress1.1d6fed1e.png"
  },
  {
    "revision": "d10f2673e6338ed1b4618f3a9ee6912a",
    "url": "./static/media/stress2.d10f2673.png"
  },
  {
    "revision": "3cb05029cd5559ae803e1c6a5c04779b",
    "url": "./static/media/stress3.3cb05029.png"
  },
  {
    "revision": "6bc32b97f46941a422dc1faf06503692",
    "url": "./static/media/stress4.6bc32b97.png"
  },
  {
    "revision": "45425d6d67319197590ee323f8ebd810",
    "url": "./static/media/stress5.45425d6d.png"
  },
  {
    "revision": "7b666cff040aca533e4190699157778d",
    "url": "./static/media/thinkingFace.7b666cff.png"
  }
]);